var KomodoConfiguration = {
    // Culture
    dateFormat: 'DD/MM/YYYY',
    timeFormat: 'HH:mm:ss',

    dateTimeFormat: 'DD/MM/YYYY HH:mm:ss',
    esbDateTimeFormat: 'DD/MM/YYYY HH:mm:ss.SSS',
    
    version: '%build-number%',
    
    localeVersion: '5',
    // Devshared
    apiUrl: 'http://10.100.27.213/fefmiddletier-tripod/api',

    ibsApiUrl: 'http://03rnb-iisintds1.za.ds.naspers.com/KomodoQueryAPIDebug/api/',//For REST Get Calls

    // Devtest  
    //apiUrl: 'https://devtestkomodo.multichoice.co.za/FefMiddleTierDebug/api',// Caching
    //connectionHubUrl: 'https://devtestkomodo.multichoice.co.za/FefMiddleTierDebug/signalr',// SignalR Configuration
    //ibsApiUrl: 'http://03rnb-iisintdt1.za.ds.naspers.com/KomodoQueryAPIDebug/api/',//For REST Get Calls

    localStorageApiUrl: 'http://localhost:51800',
    pollServerMessagesIntervals: [500, 1000, 2000, 5000],
    
    //Reconnect
    maxDaysForPreActivatedQuote: '3',
    minDaysForPreActivatedQuote: '1',
    reasonForPreActivateQuote: '1066',


    // Reports Url
    reportsUrl: 'http://03rnb-bds04:80/Reports_DEV',

    homeTileUrls: {
        namibia: {
            main: 'http://en-namibia.selfservice.dstv.com/self-service/',
            faqs: 'http://en-namibia.selfservice.dstv.com/self-service/faqs/',
            errorCodes: 'http://en-namibia.selfservice.dstv.com/self-service/error-codes/',
            howTos: 'http://en-namibia.selfservice.dstv.com/self-service/faqs/troubleshooting/',
            news: 'https://selfservice.dstv.com/self-service/operations/alerts/'
        },
        southAfrica: {
            main: 'http://selfservice.dstv.com/',
            faqs: 'http://selfservice.dstv.com/self-service/faqs/',
            errorCodes: 'http://selfservice.dstv.com/self-service/clear-errors',
            howTos: 'http://selfservice.dstv.com/self-service/how-to/',
            news: 'https://selfservice.dstv.com/self-service/operations/alerts/'
        }
    },
    
    // Localization options
    defaultLanguage: 'en',
    fallbackLanguage: 'en',

    // Timeout for all AJAX calls
    ajaxTimeout: 60000,
    
    elasticSearchConfig: {
        serverUrl: "http://03rnb-elsdvip.za.ds.naspers.com:9200/",
        numberOfRecords: 20,
        default_field: '_all',
        default_operator: 'AND'
    },

    recentCustomerCount: 10,
    interactionCount: 20,

    downloadUrls: {
        nodejs: {
            windows: {
                "installer": 'http://10.100.27.103/downloads/nodejs/nodejsinstaller.exe'
            },
            mac: {
                "universal": 'http://10.100.27.103/downloads/nodejs/ClarityService.pkg'
            }
        }
    },
    
    searchProcessResponse: {
        defaultPageSize: 10
    }
};
